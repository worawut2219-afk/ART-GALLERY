/**
 * Luminare Art Gallery & Exhibition
 * Admin Dashboard Logic (js/admin.js)
 * Features:
 * - Admin Authentication Guard (admin / admin123456)
 * - Daily Visitor Bar Chart (แผนภูมิแท่งสถิติรายวัน)
 * - Artwork CRUD (Add, Edit, Delete, Toggle Status, Image Upload Preview)
 * - Customer Orders Management
 */

document.addEventListener('DOMContentLoaded', () => {
  const adminManager = new AdminDashboard();
  adminManager.init();
});

class AdminDashboard {
  constructor() {
    this.currentEditingId = null;
    this.uploadedImageData = null;
  }

  init() {
    // 1. Check Authentication Guard
    if (!this.checkAdminAuth()) {
      return;
    }

    // 2. Setup Event Listeners & Initial Render
    this.cacheElements();
    this.setupEventListeners();
    this.renderAll();
  }

  checkAdminAuth() {
    if (!window.Luminare || !window.Luminare.isAdmin()) {
      // Prompt Admin Login Modal
      window.Luminare.openAuthModal('กรุณาเข้าสู่ระบบด้วยบัญชีผู้ดูแลระบบ (Username: admin / Password: admin123456)');
      
      // Override auth callback to reload dashboard upon successful login
      window.Luminare.pendingAuthAction = (user) => {
        if (user.role === 'admin') {
          window.location.reload();
        } else {
          alert('บัญชีนี้ไม่ใช่ผู้ดูแลระบบ กรุณาเข้าสู่ระบบด้วย admin / admin123456');
          window.Luminare.logout();
          window.location.href = 'index.html';
        }
      };
      return false;
    }
    return true;
  }

  cacheElements() {
    // Metrics
    this.metricTodayVisitors = document.getElementById('metric-today-visitors');
    this.metricWeekVisitors = document.getElementById('metric-total-week-visitors');
    this.metricTotalArtworks = document.getElementById('metric-total-artworks');
    this.metricTotalOrders = document.getElementById('metric-total-orders');

    // Chart
    this.barChartContainer = document.getElementById('daily-bar-chart-container');

    // Artworks Table & Modal
    this.artworksTbody = document.getElementById('admin-artworks-tbody');
    this.artSearchInput = document.getElementById('admin-search-art');
    this.artworkModal = document.getElementById('artwork-form-modal');
    this.artworkForm = document.getElementById('form-manage-artwork');
    this.btnAddArt = document.getElementById('btn-open-add-art-modal');
    this.btnCloseArtModal = document.getElementById('btn-close-art-modal');
    this.btnCancelArtForm = document.getElementById('btn-cancel-art-form');

    // Form inputs
    this.formId = document.getElementById('art-form-id');
    this.formTitle = document.getElementById('art-form-title-input');
    this.formArtist = document.getElementById('art-form-artist');
    this.formCategory = document.getElementById('art-form-category');
    this.formPrice = document.getElementById('art-form-price');
    this.formMedium = document.getElementById('art-form-medium');
    this.formDimensions = document.getElementById('art-form-dimensions');
    this.formYear = document.getElementById('art-form-year');
    this.formStatus = document.getElementById('art-form-status');
    this.formFileUpload = document.getElementById('art-form-file-upload');
    this.formImgUrl = document.getElementById('art-form-img-url');
    this.formImgPreview = document.getElementById('art-img-preview');
    this.formDescription = document.getElementById('art-form-description');
    this.modalTitle = document.getElementById('artwork-form-title');

    // Orders Table
    this.ordersTbody = document.getElementById('admin-orders-tbody');
    this.btnLogout = document.getElementById('btn-admin-logout');
  }

  setupEventListeners() {
    // Logout
    if (this.btnLogout) {
      this.btnLogout.addEventListener('click', () => {
        window.Luminare.logout();
        window.location.href = 'index.html';
      });
    }

    // Open Add Modal
    if (this.btnAddArt) {
      this.btnAddArt.addEventListener('click', () => this.openAddModal());
    }

    // Close Modal
    if (this.btnCloseArtModal) {
      this.btnCloseArtModal.addEventListener('click', () => this.closeModal());
    }
    if (this.btnCancelArtForm) {
      this.btnCancelArtForm.addEventListener('click', () => this.closeModal());
    }
    if (this.artworkModal) {
      this.artworkModal.addEventListener('click', (e) => {
        if (e.target === this.artworkModal) this.closeModal();
      });
    }

    // Image File Upload Preview (Converts file to base64 for instant display and persistence)
    if (this.formFileUpload) {
      this.formFileUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            this.uploadedImageData = event.target.result;
            if (this.formImgPreview) {
              this.formImgPreview.src = this.uploadedImageData;
            }
            if (this.formImgUrl) {
              this.formImgUrl.value = '';
            }
          };
          reader.readAsDataURL(file);
        }
      });
    }

    // Image URL change preview
    if (this.formImgUrl) {
      this.formImgUrl.addEventListener('input', (e) => {
        const url = e.target.value.trim();
        if (url) {
          this.uploadedImageData = url;
          if (this.formImgPreview) {
            this.formImgPreview.src = url;
          }
        }
      });
    }

    // Save Artwork Form
    if (this.artworkForm) {
      this.artworkForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.saveArtwork();
      });
    }

    // Artwork Search in Table
    if (this.artSearchInput) {
      this.artSearchInput.addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase().trim();
        this.renderArtworksTable(q);
      });
    }
  }

  renderAll() {
    this.renderMetrics();
    this.renderDailyVisitorBarChart();
    this.renderArtworksTable();
    this.renderOrdersTable();
  }

  /* ===================================================================
     1. METRICS CARDS
     =================================================================== */
  renderMetrics() {
    const stats = window.Luminare.getVisitorStats();
    const todayStr = new Date().toISOString().split('T')[0];
    const todayCount = stats[todayStr] || 0;

    // Last 7 days sum
    let weekTotal = 0;
    const sortedDates = Object.keys(stats).sort().slice(-7);
    sortedDates.forEach(d => {
      weekTotal += (stats[d] || 0);
    });

    const artworks = window.Luminare.getArtworks();
    const orders = window.Luminare.getOrders();

    if (this.metricTodayVisitors) this.metricTodayVisitors.textContent = todayCount.toLocaleString('th-TH');
    if (this.metricWeekVisitors) this.metricWeekVisitors.textContent = weekTotal.toLocaleString('th-TH');
    if (this.metricTotalArtworks) this.metricTotalArtworks.textContent = artworks.length.toLocaleString('th-TH');
    if (this.metricTotalOrders) this.metricTotalOrders.textContent = orders.length.toLocaleString('th-TH');
  }

  /* ===================================================================
     2. DAILY VISITOR BAR CHART (แผนภูมิแท่งสถิติผู้เข้าชมรายวัน)
     =================================================================== */
  renderDailyVisitorBarChart() {
    if (!this.barChartContainer) return;

    const stats = window.Luminare.getVisitorStats();
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    // Generate consecutive 7 days list up to today
    const daysList = [];
    const thaiDayNames = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];
    const thaiMonthNames = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const count = stats[dStr] || (i === 0 ? 85 : Math.floor(40 + Math.random() * 50));
      
      const dayName = thaiDayNames[d.getDay()];
      const dayNumber = d.getDate();
      const monthName = thaiMonthNames[d.getMonth()];

      daysList.push({
        dateStr: dStr,
        isToday: dStr === todayStr,
        label: `${dayName} ${dayNumber} ${monthName}`,
        count: count
      });
    }

    // Determine scale max (round up to nearest 20 or minimum 100)
    const maxVal = Math.max(...daysList.map(d => d.count), 90);
    const chartMax = Math.ceil(maxVal / 20) * 20;

    // Render bars
    this.barChartContainer.innerHTML = `
      <div class="chart-grid-lines">
        <div class="chart-grid-line"><span>${chartMax}</span></div>
        <div class="chart-grid-line"><span>${Math.round(chartMax * 0.75)}</span></div>
        <div class="chart-grid-line"><span>${Math.round(chartMax * 0.5)}</span></div>
        <div class="chart-grid-line"><span>${Math.round(chartMax * 0.25)}</span></div>
        <div class="chart-grid-line"><span>0</span></div>
      </div>
      ${daysList.map(item => {
        const heightPct = Math.max(8, Math.round((item.count / chartMax) * 100));
        return `
          <div class="bar-col" title="${item.label}: ผู้เข้าชม ${item.count} คน">
            <div class="bar-pill ${item.isToday ? 'today-bar' : ''}" style="height: ${heightPct}%;">
              <span class="bar-val-badge">${item.count}</span>
            </div>
            <div class="bar-label" style="${item.isToday ? 'font-weight: 700; color: #10B981;' : ''}">
              ${item.label} ${item.isToday ? '<br><small>(วันนี้)</small>' : ''}
            </div>
          </div>
        `;
      }).join('')}
    `;
  }

  /* ===================================================================
     3. ARTWORKS TABLE & CRUD OPERATIONS
     =================================================================== */
  renderArtworksTable(query = '') {
    if (!this.artworksTbody) return;

    let artworks = window.Luminare.getArtworks();

    if (query) {
      artworks = artworks.filter(a => 
        a.title.toLowerCase().includes(query) ||
        a.artist.toLowerCase().includes(query) ||
        a.categoryName.toLowerCase().includes(query)
      );
    }

    if (artworks.length === 0) {
      this.artworksTbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2.5rem; color: var(--text-tertiary);">
            ไม่พบผลงานศิลปะในคลัง
          </td>
        </tr>
      `;
      return;
    }

    this.artworksTbody.innerHTML = artworks.map(art => `
      <tr data-id="${art.id}">
        <td>
          <img src="${art.image}" alt="${art.title}" class="table-art-thumb">
        </td>
        <td>
          <strong>${art.title}</strong>
          <div style="font-size: 0.8rem; color: var(--text-tertiary);">${art.medium} (${art.dimensions})</div>
        </td>
        <td>${art.artist}</td>
        <td><span class="badge badge-category">${art.categoryName}</span></td>
        <td style="font-weight: 600; color: var(--accent-gold);">฿${art.price.toLocaleString('th-TH')}</td>
        <td>
          <button type="button" class="badge ${art.status === 'available' ? 'badge-available' : 'badge-sold'} btn-toggle-status" data-id="${art.id}" style="cursor: pointer; border: none;" title="คลิกเพื่อสลับสถานะ">
            ${art.status === 'available' ? '● พร้อมจำหน่าย' : '○ มีผู้สะสมแล้ว'}
          </button>
        </td>
        <td>
          <div class="table-actions">
            <button type="button" class="btn btn-outline btn-sm btn-edit-art" data-id="${art.id}" title="แก้ไขข้อมูล">
              ✏️ แก้ไข
            </button>
            <button type="button" class="btn btn-outline btn-sm btn-delete-art" data-id="${art.id}" style="color: var(--error-color);" title="ลบผลงาน">
              🗑️ ลบ
            </button>
          </div>
        </td>
      </tr>
    `).join('');

    // Attach row events
    this.artworksTbody.querySelectorAll('.btn-edit-art').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        this.openEditModal(id);
      });
    });

    this.artworksTbody.querySelectorAll('.btn-delete-art').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (confirm('คุณแน่ใจหรือไม่ว่าต้องการลบผลงานศิลปะชิ้นนี้ออกจากคลัง?')) {
          window.Luminare.deleteArtwork(id);
          this.renderAll();
        }
      });
    });

    this.artworksTbody.querySelectorAll('.btn-toggle-status').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        const art = window.Luminare.getArtworks().find(a => a.id === id);
        if (art) {
          const newStatus = art.status === 'available' ? 'sold' : 'available';
          window.Luminare.updateArtwork(id, { status: newStatus });
          this.renderAll();
        }
      });
    });
  }

  openAddModal() {
    this.currentEditingId = null;
    this.artworkForm.reset();
    this.formId.value = '';
    this.modalTitle.textContent = 'เพิ่มผลงานศิลปะใหม่เข้าสู่คลัง';
    this.uploadedImageData = 'images/art-painting-golden-dawn.jpg';
    this.formImgPreview.src = this.uploadedImageData;
    this.formYear.value = new Date().getFullYear();
    this.artworkModal.classList.add('is-active');
    document.body.style.overflow = 'hidden';
    this.formTitle.focus();
  }

  openEditModal(artId) {
    const art = window.Luminare.getArtworks().find(a => a.id === artId);
    if (!art) return;

    this.currentEditingId = artId;
    this.modalTitle.textContent = `แก้ไขผลงาน: ${art.title}`;
    this.formId.value = art.id;
    this.formTitle.value = art.title;
    this.formArtist.value = art.artist;
    this.formCategory.value = art.category;
    this.formPrice.value = art.price;
    this.formMedium.value = art.medium || '';
    this.formDimensions.value = art.dimensions || '';
    this.formYear.value = art.year || 2026;
    this.formStatus.value = art.status;
    this.formDescription.value = art.description || '';
    this.uploadedImageData = art.image;
    this.formImgPreview.src = art.image;
    this.formImgUrl.value = art.image.startsWith('data:') ? '' : art.image;

    this.artworkModal.classList.add('is-active');
    document.body.style.overflow = 'hidden';
    this.formTitle.focus();
  }

  closeModal() {
    if (this.artworkModal) {
      this.artworkModal.classList.remove('is-active');
      document.body.style.overflow = '';
    }
  }

  saveArtwork() {
    const artData = {
      title: this.formTitle.value.trim(),
      artist: this.formArtist.value.trim(),
      category: this.formCategory.value,
      price: parseFloat(this.formPrice.value) || 0,
      medium: this.formMedium.value.trim() || 'เทคนิคผสม (Mixed Media)',
      dimensions: this.formDimensions.value.trim() || 'ตามมาตรฐาน',
      year: parseInt(this.formYear.value) || new Date().getFullYear(),
      status: this.formStatus.value,
      description: this.formDescription.value.trim(),
      image: this.uploadedImageData || 'images/art-painting-golden-dawn.jpg'
    };

    if (this.currentEditingId) {
      // Update
      window.Luminare.updateArtwork(this.currentEditingId, artData);
      alert('บันทึกการแก้ไขผลงานเรียบร้อยแล้ว!');
    } else {
      // Create new
      window.Luminare.addArtwork(artData);
      alert('เพิ่มผลงานศิลปะใหม่เข้าสู่คลังเรียบร้อยแล้ว!');
    }

    this.closeModal();
    this.renderAll();
  }

  /* ===================================================================
     4. CUSTOMER ORDERS MANAGEMENT
     =================================================================== */
  renderOrdersTable() {
    if (!this.ordersTbody) return;

    const orders = window.Luminare.getOrders();

    if (orders.length === 0) {
      this.ordersTbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2.5rem; color: var(--text-tertiary);">
            ยังไม่มีรายการคำสั่งซื้อใหม่
          </td>
        </tr>
      `;
      return;
    }

    this.ordersTbody.innerHTML = orders.map(ord => {
      const dateFormatted = new Date(ord.date).toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      return `
        <tr>
          <td><strong style="font-family: var(--font-heading); color: var(--accent-gold);">${ord.orderId}</strong></td>
          <td style="font-size: 0.85rem; color: var(--text-secondary);">${dateFormatted}</td>
          <td><strong>${ord.customerName}</strong></td>
          <td>
            <div style="font-size: 0.85rem;">📞 ${ord.phone}</div>
            <div style="font-size: 0.8rem; color: var(--text-tertiary);">✉️ ${ord.email}</div>
          </td>
          <td>
            <strong>${ord.artworkTitle}</strong>
          </td>
          <td style="font-weight: 600; color: var(--text-primary);">฿${(ord.price || 0).toLocaleString('th-TH')}</td>
          <td>
            <select class="form-control select-order-status" data-order-id="${ord.orderId}" style="padding: 0.25rem 0.5rem; font-size: 0.85rem; border-radius: var(--radius-sm);">
              <option value="pending" ${ord.status === 'pending' ? 'selected' : ''}>⏳ รอดำเนินการ</option>
              <option value="confirmed" ${ord.status === 'confirmed' ? 'selected' : ''}>✅ ยืนยันคำสั่งซื้อ</option>
              <option value="shipping" ${ord.status === 'shipping' ? 'selected' : ''}>🚚 กำลังจัดส่ง</option>
              <option value="completed" ${ord.status === 'completed' ? 'selected' : ''}>🎉 ส่งมอบแล้ว</option>
            </select>
          </td>
        </tr>
      `;
    }).join('');

    // Attach status change events
    this.ordersTbody.querySelectorAll('.select-order-status').forEach(select => {
      select.addEventListener('change', (e) => {
        const orderId = select.getAttribute('data-order-id');
        const newStatus = e.target.value;
        const statusMap = {
          pending: 'รอดำเนินการ',
          confirmed: 'ยืนยันคำสั่งซื้อแล้ว',
          shipping: 'กำลังจัดส่งแบบพิเศษ',
          completed: 'ส่งมอบผลงานแล้ว'
        };
        window.Luminare.updateOrderStatus(orderId, newStatus, statusMap[newStatus]);
        this.renderMetrics();
      });
    });
  }
}
