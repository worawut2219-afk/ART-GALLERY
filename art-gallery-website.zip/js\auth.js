/**
 * Luminare Art Gallery & Exhibition
 * Auth & Data Persistence System (js/auth.js)
 * Features:
 * - Admin Authentication (admin / admin123456)
 * - Member Authentication & Registration
 * - Daily Visitor Tracking & Analytics Data
 * - Artwork CRUD persistence in localStorage
 * - Customer Orders & Inquiries persistence in localStorage
 * - Global Login/Register Modal Dialog
 */

// Initial Default Artworks (Fallback if localStorage is empty)
const DEFAULT_ARTWORKS = [
  {
    id: 'art-001',
    title: 'รุ่งอรุณสีทอง (Golden Dawn of Siam)',
    artist: 'กฤษณะ วงศ์สวรรค์',
    category: 'painting',
    categoryName: 'จิตรกรรม',
    year: 2025,
    medium: 'สีน้ำมันบนผืนผ้าใบ (Oil on Canvas)',
    dimensions: '120 x 90 ซม.',
    price: 85000,
    status: 'available',
    featured: true,
    image: 'images/art-painting-golden-dawn.jpg',
    description: 'ผลงานถ่ายทอดแสงแรกของวันใหม่ที่สะท้อนลงสู่สถาปัตยกรรมและผืนน้ำไทย ผสานเทคนิคแสงเงาแบบอิมเพรสชันนิสม์ร่วมสมัย สื่อถึงความหวังและการเริ่มต้นใหม่ที่เปี่ยมด้วยพลังศรัทธา',
    artistBio: 'ศิลปินปริญญาโทด้านจิตรกรรม ผู้เคยได้รับรางวัลเหรียญทองจิตรกรรมบัวหลวง จัดแสดงงานทั้งในเอเชียและยุโรป'
  },
  {
    id: 'art-002',
    title: 'ความสงบนิรันดร์ (Serenity in Motion)',
    artist: 'พิมลดา สุวรรณสิทธิ์',
    category: 'painting',
    categoryName: 'จิตรกรรม',
    year: 2024,
    medium: 'สีอะคริลิกและผงทองคำเปลว (Acrylic & Gold Leaf)',
    dimensions: '100 x 100 ซม.',
    price: 68000,
    status: 'available',
    featured: false,
    image: 'images/art-painting-serenity.jpg',
    description: 'ความกลมกลืนระหว่างเส้นสายที่เป็นนามธรรมและความเงียบสงบ การใช้โทนสีธรรมชาติผสานกับแผ่นทองคำเปลวแท้ สะท้อนปรัชญาเซนและความสงบทางจิตใจ',
    artistBio: 'ศิลปินร่วมสมัยผู้เชี่ยวชาญด้านศิลปะนามธรรมเชิงจิตวิญญาณ ผลงานจัดแสดงในหอศิลป์ระดับนานาชาติ'
  },
  {
    id: 'art-003',
    title: 'สมดุลแห่งจิต (Harmony of Soul)',
    artist: 'อัครพล ชนะศิลป์',
    category: 'sculpture',
    categoryName: 'ประติมากรรม',
    year: 2025,
    medium: 'หินอ่อนขาวและทองเหลืองขัดเงา (White Marble & Brass)',
    dimensions: '65 x 40 x 30 ซม.',
    price: 145000,
    status: 'available',
    featured: true,
    image: 'images/art-sculpture-harmony.jpg',
    description: 'ประติมากรรมรูปทรงนามธรรมที่เกิดจากการแกะสลักหินอ่อนธรรมชาติ ผสานองค์ประกอบทองเหลืองเพื่อสร้างจุดเชื่อมโยงระหว่างความหนักแน่นของหินและความพริ้วไหวของแสง',
    artistBio: 'ประติมากรชั้นนำรุ่นใหม่ ผู้ผ่านการศึกษาด้านประติมากรรมจากอิตาลี มีผลงานจัดวางในอาคารสถาปัตยกรรมสำคัญหลายแห่ง'
  },
  {
    id: 'art-004',
    title: 'สายธารกาลเวลา (Eternal Flow)',
    artist: 'ชานนท์ ปิติโชติ',
    category: 'sculpture',
    categoryName: 'ประติมากรรม',
    year: 2023,
    medium: 'สำริดรมดำ (Patinated Cast Bronze)',
    dimensions: '80 x 50 x 45 ซม.',
    price: 190000,
    status: 'sold',
    featured: false,
    image: 'images/art-sculpture-eternal-flow.jpg',
    description: 'ผลงานสำริดทรงคุณค่าที่แสดงถึงการไหลเวียนของเวลาและวัฏจักรชีวิต เส้นสายที่โค้งมนต่อเนื่องสื่อถึงความไม่สิ้นสุดและอิสรภาพ',
    artistBio: 'ศิลปินอาวุโสผู้สร้างสรรค์งานหล่อสำริดมากว่า 25 ปี ผลงานสะสมโดยพิพิธภัณฑ์ศิลปะและนักสะสมเอกชนชั้นนำ'
  },
  {
    id: 'art-005',
    title: 'ทัศนียภาพแสงสยาม (Bangkok Luminescence)',
    artist: 'ธีรเดช มหิทธา',
    category: 'photography',
    categoryName: 'ภาพถ่าย',
    year: 2025,
    medium: 'ภาพถ่าย Fine Art Print บนกระดาษ Hahnemühle กราไฟท์การันตี 100 ปี (Edition 1/5)',
    dimensions: '90 x 60 ซม.',
    price: 42000,
    status: 'available',
    featured: true,
    image: 'images/art-photo-bangkok-light.jpg',
    description: 'ภาพถ่ายสถาปัตยกรรมกรุงเทพฯ ยามทไวไลท์ ถ่ายทอดความตัดกันระหว่างเส้นสายโมเดิร์นกับวิถีชีวิตคนเมือง บันทึกด้วยกล้องฟูลเฟรมความละเอียดสูงและพิมพ์ระบบพิพิธภัณฑ์',
    artistBio: 'ช่างภาพวิจิตรศิลป์ระดับรางวัลชนะเลิศ National Geographic Thailand Photography Awards'
  },
  {
    id: 'art-006',
    title: 'ทะเลหมอกภูบรรพต (Misty Highlands)',
    artist: 'นลินี วัฒนพงศ์',
    category: 'photography',
    categoryName: 'ภาพถ่าย',
    year: 2024,
    medium: 'Archival Pigment Print เคลือบอะคริลิกไร้ขอบ (Edition 2/7)',
    dimensions: '120 x 80 ซม.',
    price: 48000,
    status: 'sold',
    featured: false,
    image: 'images/art-photo-misty-mountains.jpg',
    description: 'ภาพบันทึกธรรมชาติยอดดอยสูงในเชียงรายที่ถูกโอบกอดด้วยไอหมอกขาวและแสงตะวันยามเช้า ให้ความรู้สึกสงบนิ่งและลึกล้ำทางสุนทรียศาสตร์',
    artistBio: 'ศิลปินช่างภาพทิวทัศน์ที่เดินทางบันทึกเรื่องราวของเทือกเขาและป่าเมืองไทยมากว่า 15 ปี'
  },
  {
    id: 'art-007',
    title: 'บงกชไซเบอร์ (Cyber Lotus Symphony)',
    artist: 'วรินทร ดิจิทัลแล็บ',
    category: 'digital',
    categoryName: 'ดิจิทัลอาร์ต',
    year: 2025,
    medium: '3D Generative Art + NFT Smart Contract & Ultra HD Diasec Display (1/1)',
    dimensions: 'จอแสดงผลดิจิทัล 4K ขนาด 55 นิ้ว พร้อมกรอบไม้สักแท้',
    price: 120000,
    status: 'available',
    featured: true,
    image: 'images/art-digital-cyber-lotus.jpg',
    description: 'การนำสัญลักษณ์ดอกบัวหลวงไทยมาตีความใหม่ในรูปแบบโลกไซเบอร์ สร้างสรรค์ด้วยคณิตศาสตร์ขั้นตอนวิธี (Generative Algorithm) เคลื่อนไหวตามสภาพบรรยากาศ',
    artistBio: 'ครีเอทีฟโค้ดเดอร์และดิจิทัลอาร์ติสต์รุ่นใหม่ ผู้บุกเบิกการผสมผสานศิลปะไทยเข้ากับเทคโนโลยี Generative Media'
  },
  {
    id: 'art-008',
    title: 'มิติความคิดนามธรรม (Abstract Mindscape)',
    artist: 'กฤตยชญ์ เทวรักษ์',
    category: 'digital',
    categoryName: 'ดิจิทัลอาร์ต',
    year: 2024,
    medium: 'Digital Mixed Media พิมพ์ลงบนแผ่นอลูมิเนียมคอมโพสิตขัดด้าน',
    dimensions: '110 x 75 ซม.',
    price: 55000,
    status: 'available',
    featured: false,
    image: 'images/art-digital-abstract-mind.jpg',
    description: 'การสำรวจคลื่นสมองและอารมณ์ความรู้สึกของมนุษย์ยุคดิจิทัลผ่านสีสันที่สดใสและการเคลื่อนไหวเชิงอนุภาค สร้างมิติทางสายตาที่น่าดึงดูดใจ',
    artistBio: 'ดิจิทัลอิลลัสเตรเตอร์และนักออกแบบกราฟิกร่วมสมัย ผู้มีผลงานร่วมงานกับแบรนด์ชั้นนำระดับสากล'
  }
];

class LuminareApp {
  constructor() {
    this.STORAGE_KEYS = {
      AUTH_USER: 'luminare_auth_user',
      USERS_DB: 'luminare_registered_users',
      ARTWORKS: 'luminare_artworks_catalog',
      ORDERS: 'luminare_customer_orders',
      VISITORS: 'luminare_daily_visitor_stats',
      SESSION_VISITED: 'luminare_session_visited_flag'
    };

    this.pendingAuthAction = null;
    this.initStorage();
    this.trackVisit();
    this.initHeaderUserUI();
    this.initAuthModal();
  }

  /* ===================================================================
     STORAGE INITIALIZATION
     =================================================================== */
  initStorage() {
    // 1. Initialize Artworks if empty
    if (!localStorage.getItem(this.STORAGE_KEYS.ARTWORKS)) {
      localStorage.setItem(this.STORAGE_KEYS.ARTWORKS, JSON.stringify(DEFAULT_ARTWORKS));
    }

    // 2. Initialize Users DB with default Member demo account
    if (!localStorage.getItem(this.STORAGE_KEYS.USERS_DB)) {
      const defaultUsers = [
        {
          username: 'user',
          name: 'สมชาย ผู้รักศิลปะ',
          email: 'user@example.com',
          phone: '0812345678',
          password: 'password123',
          role: 'member'
        }
      ];
      localStorage.setItem(this.STORAGE_KEYS.USERS_DB, JSON.stringify(defaultUsers));
    }

    // 3. Initialize Visitor Statistics (7 Days baseline)
    if (!localStorage.getItem(this.STORAGE_KEYS.VISITORS)) {
      const initialStats = {};
      const today = new Date();
      // Generate realistic daily visitors for past 7 days
      const counts = [42, 58, 36, 64, 78, 92, 85];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(today.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        initialStats[dateStr] = counts[6 - i] || 50;
      }
      localStorage.setItem(this.STORAGE_KEYS.VISITORS, JSON.stringify(initialStats));
    }

    // 4. Initialize Orders list if empty
    if (!localStorage.getItem(this.STORAGE_KEYS.ORDERS)) {
      const sampleOrders = [
        {
          orderId: 'LUM-849102',
          date: new Date(Date.now() - 86400000 * 2).toISOString(),
          customerName: 'คุณวราภรณ์ สถิตศิลป์',
          email: 'varaporn@artcollector.co',
          phone: '0891234567',
          artworkId: 'art-004',
          artworkTitle: 'สายธารกาลเวลา (Eternal Flow)',
          price: 190000,
          status: 'completed',
          statusText: 'ส่งมอบผลงานแล้ว'
        },
        {
          orderId: 'LUM-923154',
          date: new Date(Date.now() - 86400000).toISOString(),
          customerName: 'คุณธนวัฒน์ พัฒนชัย',
          email: 'tanawat@corporate.th',
          phone: '0867890123',
          artworkId: 'art-006',
          artworkTitle: 'ทะเลหมอกภูบรรพต (Misty Highlands)',
          price: 48000,
          status: 'shipping',
          statusText: 'กำลังจัดส่งแบบพิเศษ'
        }
      ];
      localStorage.setItem(this.STORAGE_KEYS.ORDERS, JSON.stringify(sampleOrders));
    }
  }

  /* ===================================================================
     DAILY VISITOR TRACKING
     =================================================================== */
  trackVisit() {
    // Only count once per browser tab session to avoid refreshing inflating numbers artificially
    if (!sessionStorage.getItem(this.STORAGE_KEYS.SESSION_VISITED)) {
      const todayStr = new Date().toISOString().split('T')[0];
      const stats = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.VISITORS) || '{}');
      stats[todayStr] = (stats[todayStr] || 0) + 1;
      localStorage.setItem(this.STORAGE_KEYS.VISITORS, JSON.stringify(stats));
      sessionStorage.setItem(this.STORAGE_KEYS.SESSION_VISITED, 'true');
    }
  }

  getVisitorStats() {
    return JSON.parse(localStorage.getItem(this.STORAGE_KEYS.VISITORS) || '{}');
  }

  /* ===================================================================
     AUTHENTICATION LOGIC (Admin: admin / admin123456)
     =================================================================== */
  getCurrentUser() {
    try {
      return JSON.parse(localStorage.getItem(this.STORAGE_KEYS.AUTH_USER));
    } catch {
      return null;
    }
  }

  isLoggedIn() {
    return !!this.getCurrentUser();
  }

  isAdmin() {
    const user = this.getCurrentUser();
    return user && user.role === 'admin';
  }

  login(usernameOrEmail, password) {
    const cleanUser = usernameOrEmail.trim().toLowerCase();
    const cleanPass = password.trim();

    // 1. Check Admin Credentials (admin / admin123456)
    if (cleanUser === 'admin' && cleanPass === 'admin123456') {
      const adminSession = {
        username: 'admin',
        name: 'ผู้ดูแลระบบ (Admin Curator)',
        email: 'admin@luminaregallery.art',
        role: 'admin',
        loginTime: new Date().toISOString()
      };
      localStorage.setItem(this.STORAGE_KEYS.AUTH_USER, JSON.stringify(adminSession));
      this.updateHeaderUserUI();
      return { success: true, user: adminSession };
    }

    // 2. Check Registered Members
    const users = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.USERS_DB) || '[]');
    const matchedUser = users.find(u => 
      (u.username.toLowerCase() === cleanUser || u.email.toLowerCase() === cleanUser) && 
      u.password === cleanPass
    );

    if (matchedUser) {
      const userSession = {
        username: matchedUser.username,
        name: matchedUser.name,
        email: matchedUser.email,
        phone: matchedUser.phone,
        role: 'member',
        loginTime: new Date().toISOString()
      };
      localStorage.setItem(this.STORAGE_KEYS.AUTH_USER, JSON.stringify(userSession));
      this.updateHeaderUserUI();
      return { success: true, user: userSession };
    }

    return { 
      success: false, 
      message: 'ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง (สำหรับ Admin กรุณาใช้ admin / admin123456)' 
    };
  }

  register(name, email, phone, username, password) {
    const users = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.USERS_DB) || '[]');
    
    // Check duplication
    if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
      return { success: false, message: 'ชื่อผู้ใช้นี้ถูกใช้งานแล้ว' };
    }
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { success: false, message: 'อีเมลนี้มีในระบบแล้ว' };
    }

    const newUser = {
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      username: username.trim(),
      password: password.trim(),
      role: 'member'
    };

    users.push(newUser);
    localStorage.setItem(this.STORAGE_KEYS.USERS_DB, JSON.stringify(users));

    // Auto-login upon register
    const userSession = {
      username: newUser.username,
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      role: 'member',
      loginTime: new Date().toISOString()
    };
    localStorage.setItem(this.STORAGE_KEYS.AUTH_USER, JSON.stringify(userSession));
    this.updateHeaderUserUI();
    return { success: true, user: userSession };
  }

  logout() {
    localStorage.removeItem(this.STORAGE_KEYS.AUTH_USER);
    this.updateHeaderUserUI();
    // If currently on admin page, redirect to home
    if (window.location.pathname.includes('admin.html')) {
      window.location.href = 'index.html';
    }
  }

  /**
   * Enforces login before executing action
   */
  requireAuth(onSuccessCallback, message = 'กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อผลงาน') {
    if (this.isLoggedIn()) {
      onSuccessCallback(this.getCurrentUser());
    } else {
      this.pendingAuthAction = onSuccessCallback;
      this.openAuthModal(message);
    }
  }

  /* ===================================================================
     ARTWORK CRUD OPERATIONS (Persisted in localStorage)
     =================================================================== */
  getArtworks() {
    try {
      return JSON.parse(localStorage.getItem(this.STORAGE_KEYS.ARTWORKS)) || DEFAULT_ARTWORKS;
    } catch {
      return DEFAULT_ARTWORKS;
    }
  }

  saveArtworks(artworks) {
    localStorage.setItem(this.STORAGE_KEYS.ARTWORKS, JSON.stringify(artworks));
  }

  addArtwork(artData) {
    const artworks = this.getArtworks();
    const newId = 'art-' + String(Date.now()).slice(-4);
    const newArt = {
      id: newId,
      title: artData.title,
      artist: artData.artist,
      category: artData.category,
      categoryName: artData.categoryName || this.getCategoryName(artData.category),
      year: parseInt(artData.year) || new Date().getFullYear(),
      medium: artData.medium,
      dimensions: artData.dimensions,
      price: parseFloat(artData.price) || 0,
      status: artData.status || 'available',
      featured: !!artData.featured,
      image: artData.image || 'images/art-painting-golden-dawn.jpg',
      description: artData.description || 'ผลงานศิลปะร่วมสมัยชิ้นเอก',
      artistBio: artData.artistBio || 'ศิลปินร่วมสมัยผู้สร้างสรรค์ผลงานคุณภาพ'
    };

    artworks.unshift(newArt);
    this.saveArtworks(artworks);
    return newArt;
  }

  updateArtwork(artId, updateData) {
    const artworks = this.getArtworks();
    const index = artworks.findIndex(a => a.id === artId);
    if (index === -1) return false;

    artworks[index] = {
      ...artworks[index],
      ...updateData,
      categoryName: updateData.category ? this.getCategoryName(updateData.category) : artworks[index].categoryName
    };

    this.saveArtworks(artworks);
    return true;
  }

  deleteArtwork(artId) {
    let artworks = this.getArtworks();
    artworks = artworks.filter(a => a.id !== artId);
    this.saveArtworks(artworks);
    return true;
  }

  getCategoryName(cat) {
    const map = {
      painting: 'จิตรกรรม',
      sculpture: 'ประติมากรรม',
      photography: 'ภาพถ่าย',
      digital: 'ดิจิทัลอาร์ต'
    };
    return map[cat] || 'ศิลปะร่วมสมัย';
  }

  /* ===================================================================
     ORDER MANAGEMENT
     =================================================================== */
  getOrders() {
    try {
      return JSON.parse(localStorage.getItem(this.STORAGE_KEYS.ORDERS)) || [];
    } catch {
      return [];
    }
  }

  createOrder(orderData) {
    const orders = this.getOrders();
    const orderId = 'LUM-' + Math.floor(100000 + Math.random() * 900000);
    
    const newOrder = {
      orderId: orderId,
      date: new Date().toISOString(),
      customerName: orderData.customerName,
      email: orderData.email,
      phone: orderData.phone,
      artworkId: orderData.artworkId || null,
      artworkTitle: orderData.artworkTitle,
      price: orderData.price || 0,
      shippingAddress: orderData.message || orderData.address || 'ตามการประสานงาน',
      status: 'pending',
      statusText: 'รอดำเนินการยืนยัน'
    };

    orders.unshift(newOrder);
    localStorage.setItem(this.STORAGE_KEYS.ORDERS, JSON.stringify(orders));

    // Also mark artwork status as sold if artworkId exists
    if (orderData.artworkId) {
      this.updateArtwork(orderData.artworkId, { status: 'sold' });
    }

    return newOrder;
  }

  updateOrderStatus(orderId, newStatus, newStatusText) {
    const orders = this.getOrders();
    const order = orders.find(o => o.orderId === orderId);
    if (order) {
      order.status = newStatus;
      order.statusText = newStatusText;
      localStorage.setItem(this.STORAGE_KEYS.ORDERS, JSON.stringify(orders));
      return true;
    }
    return false;
  }

  /* ===================================================================
     HEADER USER PROFILE UI INTEGRATION
     =================================================================== */
  initHeaderUserUI() {
    // Check if header actions element exists
    const actions = document.querySelector('.header-actions');
    if (!actions) return;

    // Create user container if not present
    let userBox = document.getElementById('header-auth-box');
    if (!userBox) {
      userBox = document.createElement('div');
      userBox.id = 'header-auth-box';
      userBox.className = 'header-auth-box';
      actions.insertBefore(userBox, actions.firstChild);
    }

    this.updateHeaderUserUI();
  }

  updateHeaderUserUI() {
    const userBox = document.getElementById('header-auth-box');
    if (!userBox) return;

    const user = this.getCurrentUser();

    if (user) {
      const isAdm = user.role === 'admin';
      userBox.innerHTML = `
        <div class="user-menu-dropdown">
          <button type="button" class="user-badge-btn" id="user-badge-btn" aria-haspopup="true" aria-expanded="false">
            <span class="user-avatar-circle" aria-hidden="true">${isAdm ? '👑' : '🎨'}</span>
            <span class="user-name-label">${user.name.split(' ')[0]}</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
          <div class="user-dropdown-panel" id="user-dropdown-panel">
            <div class="user-dropdown-header">
              <strong>${user.name}</strong>
              <small>${user.email}</small>
              <span class="badge ${isAdm ? 'badge-featured' : 'badge-available'}" style="margin-top: 0.25rem;">
                ${isAdm ? 'ผู้ดูแลระบบ (Admin)' : 'สมาชิกผู้สะสม'}
              </span>
            </div>
            <ul class="user-dropdown-list">
              ${isAdm ? `
                <li>
                  <a href="admin.html" class="user-dropdown-link" style="color: var(--accent-gold); font-weight: 600;">
                    ⚙️ ระบบหลังบ้าน (Admin Dashboard)
                  </a>
                </li>
              ` : `
                <li>
                  <a href="gallery.html" class="user-dropdown-link">
                    🖼️ เลือกชมและสั่งซื้อผลงาน
                  </a>
                </li>
              `}
              <li>
                <button type="button" class="user-dropdown-link btn-logout" id="btn-global-logout">
                  🚪 ออกจากระบบ (Logout)
                </button>
              </li>
            </ul>
          </div>
        </div>
      `;

      // Toggle dropdown behavior
      const badgeBtn = userBox.querySelector('#user-badge-btn');
      const panel = userBox.querySelector('#user-dropdown-panel');
      const logoutBtn = userBox.querySelector('#btn-global-logout');

      if (badgeBtn && panel) {
        badgeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const open = panel.classList.toggle('is-open');
          badgeBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        document.addEventListener('click', () => {
          panel.classList.remove('is-open');
          badgeBtn.setAttribute('aria-expanded', 'false');
        });
      }

      if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
          this.logout();
        });
      }

    } else {
      userBox.innerHTML = `
        <button type="button" class="btn btn-outline btn-sm" id="btn-open-login" style="padding: 0.4rem 0.85rem; font-size: 0.85rem;">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
          เข้าสู่ระบบ
        </button>
      `;

      const loginBtn = userBox.querySelector('#btn-open-login');
      if (loginBtn) {
        loginBtn.addEventListener('click', () => this.openAuthModal());
      }
    }
  }

  /* ===================================================================
     GLOBAL LOGIN / REGISTER MODAL
     =================================================================== */
  initAuthModal() {
    if (document.getElementById('auth-modal-dialog')) return;

    const modalHTML = `
      <div class="modal-overlay" id="auth-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-modal-title">
        <div class="modal-container" style="max-width: 440px;">
          <button type="button" class="modal-close-btn" id="auth-modal-close" aria-label="ปิดหน้าต่าง">&times;</button>
          
          <div style="padding: 2.25rem 2rem 2rem 2rem;">
            <div style="text-align: center; margin-bottom: 1.5rem;">
              <img src="images/logo.svg" alt="Luminare Art Gallery" style="height: 38px; margin: 0 auto 0.75rem auto;">
              <h2 id="auth-modal-title" style="font-size: 1.45rem;">เข้าสู่ระบบสมาชิก</h2>
              <p id="auth-modal-hint" style="font-size: 0.88rem; color: var(--accent-gold); margin-top: 0.35rem;">
                กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อผลงานศิลปะ
              </p>
            </div>

            <!-- Login Form -->
            <form id="form-login-auth">
              <div class="form-group" style="margin-bottom: 1.15rem;">
                <label for="auth-login-user" class="form-label">ชื่อผู้ใช้ หรือ อีเมล</label>
                <input type="text" id="auth-login-user" class="form-control" placeholder="เช่น admin หรือ user@example.com" required autocomplete="username">
              </div>

              <div class="form-group" style="margin-bottom: 1.25rem;">
                <label for="auth-login-pass" class="form-label">รหัสผ่าน</label>
                <input type="password" id="auth-login-pass" class="form-control" placeholder="••••••••" required autocomplete="current-password">
              </div>

              <div id="auth-error-msg" style="display: none; color: var(--error-color); background: var(--error-bg); padding: 0.65rem; border-radius: var(--radius-sm); font-size: 0.85rem; margin-bottom: 1rem;"></div>

              <button type="submit" class="btn btn-primary btn-block" style="margin-bottom: 1rem;">
                เข้าสู่ระบบ
              </button>

              <!-- Quick Demo Access Hint -->
              <div style="background-color: var(--bg-tertiary); padding: 0.85rem; border-radius: var(--radius-sm); font-size: 0.8rem; line-height: 1.5; color: var(--text-secondary); border: 1px dashed var(--border-medium);">
                <strong>🔑 ข้อมูลสำหรับทดสอบระบบ:</strong><br>
                • <strong>Admin:</strong> Username: <code style="color: var(--accent-gold);">admin</code> / Password: <code style="color: var(--accent-gold);">admin123456</code><br>
                • <strong>Member:</strong> Username: <code>user</code> / Password: <code>password123</code>
              </div>

              <div style="text-align: center; margin-top: 1.25rem; font-size: 0.9rem;">
                ยังไม่มีบัญชีผู้ใช้? 
                <button type="button" id="btn-switch-to-register" style="background: none; border: none; color: var(--accent-gold); cursor: pointer; text-decoration: underline; font-weight: 600;">
                  สมัครสมาชิกใหม่
                </button>
              </div>
            </form>

            <!-- Register Form (Initially Hidden) -->
            <form id="form-register-auth" style="display: none;">
              <div class="form-group" style="margin-bottom: 1rem;">
                <label for="auth-reg-name" class="form-label">ชื่อ-นามสกุล</label>
                <input type="text" id="auth-reg-name" class="form-control" placeholder="เช่น กิตติพงษ์ เจริญศิลป์" required>
              </div>

              <div class="form-group" style="margin-bottom: 1rem;">
                <label for="auth-reg-email" class="form-label">อีเมล</label>
                <input type="email" id="auth-reg-email" class="form-control" placeholder="name@example.com" required>
              </div>

              <div class="form-group" style="margin-bottom: 1rem;">
                <label for="auth-reg-phone" class="form-label">เบอร์โทรศัพท์</label>
                <input type="tel" id="auth-reg-phone" class="form-control" placeholder="08XXXXXXXX" required>
              </div>

              <div class="form-group" style="margin-bottom: 1rem;">
                <label for="auth-reg-username" class="form-label">ชื่อผู้ใช้ (Username)</label>
                <input type="text" id="auth-reg-username" class="form-control" placeholder="username" required>
              </div>

              <div class="form-group" style="margin-bottom: 1.25rem;">
                <label for="auth-reg-pass" class="form-label">ตั้งรหัสผ่าน</label>
                <input type="password" id="auth-reg-pass" class="form-control" placeholder="อย่างน้อย 6 ตัวอักษร" required minlength="6">
              </div>

              <div id="auth-reg-error-msg" style="display: none; color: var(--error-color); background: var(--error-bg); padding: 0.65rem; border-radius: var(--radius-sm); font-size: 0.85rem; margin-bottom: 1rem;"></div>

              <button type="submit" class="btn btn-primary btn-block" style="margin-bottom: 1rem;">
                ยืนยันการสมัครสมาชิก
              </button>

              <div style="text-align: center; font-size: 0.9rem;">
                มีบัญชีอยู่แล้ว? 
                <button type="button" id="btn-switch-to-login" style="background: none; border: none; color: var(--accent-gold); cursor: pointer; text-decoration: underline; font-weight: 600;">
                  กลับสู่หน้าเข้าสู่ระบบ
                </button>
              </div>
            </form>

          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);

    const modal = document.getElementById('auth-modal-dialog');
    const closeBtn = document.getElementById('auth-modal-close');
    const loginForm = document.getElementById('form-login-auth');
    const regForm = document.getElementById('form-register-auth');
    const switchToReg = document.getElementById('btn-switch-to-register');
    const switchToLogin = document.getElementById('btn-switch-to-login');
    const modalTitle = document.getElementById('auth-modal-title');
    const errorMsg = document.getElementById('auth-error-msg');
    const regErrorMsg = document.getElementById('auth-reg-error-msg');

    // Close Modal Events
    closeBtn.addEventListener('click', () => this.closeAuthModal());
    modal.addEventListener('click', (e) => {
      if (e.target === modal) this.closeAuthModal();
    });

    // Switch forms
    switchToReg.addEventListener('click', () => {
      loginForm.style.display = 'none';
      regForm.style.display = 'block';
      modalTitle.textContent = 'สมัครสมาชิกใหม่';
      if (errorMsg) errorMsg.style.display = 'none';
    });

    switchToLogin.addEventListener('click', () => {
      regForm.style.display = 'none';
      loginForm.style.display = 'block';
      modalTitle.textContent = 'เข้าสู่ระบบสมาชิก';
      if (regErrorMsg) regErrorMsg.style.display = 'none';
    });

    // Handle Login Submit
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const userVal = document.getElementById('auth-login-user').value;
      const passVal = document.getElementById('auth-login-pass').value;

      const result = this.login(userVal, passVal);
      if (result.success) {
        this.closeAuthModal();
        if (this.pendingAuthAction) {
          const action = this.pendingAuthAction;
          this.pendingAuthAction = null;
          action(result.user);
        } else if (result.user.role === 'admin' && !window.location.pathname.includes('admin.html')) {
          // If admin logged in, ask if they want to go to admin dashboard
          if (confirm('เข้าสู่ระบบ Admin สำเร็จ! ต้องการไปยังระบบหลังบ้าน (Admin Dashboard) หรือไม่?')) {
            window.location.href = 'admin.html';
          }
        }
      } else {
        errorMsg.textContent = result.message;
        errorMsg.style.display = 'block';
      }
    });

    // Handle Register Submit
    regForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('auth-reg-name').value;
      const email = document.getElementById('auth-reg-email').value;
      const phone = document.getElementById('auth-reg-phone').value;
      const username = document.getElementById('auth-reg-username').value;
      const pass = document.getElementById('auth-reg-pass').value;

      const result = this.register(name, email, phone, username, pass);
      if (result.success) {
        this.closeAuthModal();
        if (this.pendingAuthAction) {
          const action = this.pendingAuthAction;
          this.pendingAuthAction = null;
          action(result.user);
        }
      } else {
        regErrorMsg.textContent = result.message;
        regErrorMsg.style.display = 'block';
      }
    });
  }

  openAuthModal(hintMessage) {
    const modal = document.getElementById('auth-modal-dialog');
    const hintEl = document.getElementById('auth-modal-hint');
    const loginForm = document.getElementById('form-login-auth');
    const regForm = document.getElementById('form-register-auth');
    const modalTitle = document.getElementById('auth-modal-title');
    const errorMsg = document.getElementById('auth-error-msg');

    if (!modal) return;

    if (hintEl && hintMessage) {
      hintEl.textContent = hintMessage;
    }

    if (loginForm) loginForm.style.display = 'block';
    if (regForm) regForm.style.display = 'none';
    if (modalTitle) modalTitle.textContent = 'เข้าสู่ระบบสมาชิก';
    if (errorMsg) errorMsg.style.display = 'none';

    modal.classList.add('is-active');
    document.body.style.overflow = 'hidden';
    document.getElementById('auth-login-user')?.focus();
  }

  closeAuthModal() {
    const modal = document.getElementById('auth-modal-dialog');
    if (modal) {
      modal.classList.remove('is-active');
      document.body.style.overflow = '';
    }
  }
}

// Global instance accessible everywhere
window.Luminare = new LuminareApp();
