/**
 * Luminare Art Gallery & Exhibition
 * Contact & Inquiries: Form Validation, Auth Guard for Purchasing, and Order Success Modal
 */

document.addEventListener('DOMContentLoaded', () => {
  initContactFormValidation();
  initFaqAccordion();
  prefillArtworkFromUrl();
  prefillUserInfoIfLoggedIn();
});

function prefillUserInfoIfLoggedIn() {
  if (!window.Luminare || !window.Luminare.isLoggedIn()) return;
  const user = window.Luminare.getCurrentUser();
  if (!user) return;

  const nameField = document.getElementById('contact-name');
  const emailField = document.getElementById('contact-email');
  const phoneField = document.getElementById('contact-phone');

  if (nameField && !nameField.value) nameField.value = user.name;
  if (emailField && !emailField.value) emailField.value = user.email;
  if (phoneField && !phoneField.value && user.phone) phoneField.value = user.phone;
}

/* ===================================================================
   INTERACTIVE FORM VALIDATION & ORDER PROCESSING WITH AUTH GUARD
   =================================================================== */
function initContactFormValidation() {
  const form = document.getElementById('gallery-contact-form');
  if (!form) return;

  const fields = {
    fullname: document.getElementById('contact-name'),
    email: document.getElementById('contact-email'),
    phone: document.getElementById('contact-phone'),
    inquiryType: document.getElementById('contact-type'),
    artwork: document.getElementById('contact-artwork'),
    message: document.getElementById('contact-message'),
    consent: document.getElementById('contact-consent')
  };

  const submitBtn = document.getElementById('contact-submit-btn');

  // Regular Expressions for Validation
  const patterns = {
    email: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    phone: /^0[689]\d{8}$|^0[2-57]\d{7}$/
  };

  function validateField(field) {
    if (!field) return true;
    const value = field.value ? field.value.trim() : '';
    let isValid = true;
    let errorMessage = '';

    const feedbackEl = field.closest('.form-group')?.querySelector('.form-feedback');

    switch (field.id) {
      case 'contact-name':
        if (!value) {
          isValid = false;
          errorMessage = 'กรุณาระบุชื่อ-นามสกุลของคุณ';
        } else if (value.length < 2) {
          isValid = false;
          errorMessage = 'ชื่อ-นามสกุลต้องมีความยาวอย่างน้อย 2 ตัวอักษร';
        }
        break;

      case 'contact-email':
        if (!value) {
          isValid = false;
          errorMessage = 'กรุณาระบุที่อยู่อีเมลสำหรับติดต่อกลับ';
        } else if (!patterns.email.test(value)) {
          isValid = false;
          errorMessage = 'รูปแบบอีเมลไม่ถูกต้อง เช่น yourname@example.com';
        }
        break;

      case 'contact-phone':
        if (!value) {
          isValid = false;
          errorMessage = 'กรุณาระบุหมายเลขโทรศัพท์';
        } else {
          const cleanPhone = value.replace(/[-\s]/g, '');
          if (!patterns.phone.test(cleanPhone)) {
            isValid = false;
            errorMessage = 'กรุณากรอกหมายเลขโทรศัพท์ไทย 9-10 หลัก (เช่น 0812345678)';
          }
        }
        break;

      case 'contact-type':
        if (!value) {
          isValid = false;
          errorMessage = 'กรุณาเลือกประเภทการติดต่อ';
        }
        break;

      case 'contact-message':
        if (!value) {
          isValid = false;
          errorMessage = 'กรุณาระบุข้อความหรือรายละเอียดที่ต้องการติดต่อ';
        } else if (value.length < 10) {
          isValid = false;
          errorMessage = 'ข้อความควรมีความยาวอย่างน้อย 10 ตัวอักษร เพื่อให้เจ้าหน้าที่ดูแลได้อย่างถูกต้อง';
        }
        break;

      case 'contact-consent':
        if (!field.checked) {
          isValid = false;
          errorMessage = 'กรุณาทำเครื่องหมายยอมรับข้อกำหนดความเป็นส่วนตัว';
        }
        break;
    }

    if (isValid) {
      field.classList.remove('is-invalid');
      field.classList.add('is-valid');
      if (feedbackEl) feedbackEl.style.display = 'none';
    } else {
      field.classList.remove('is-valid');
      field.classList.add('is-invalid');
      if (feedbackEl) {
        feedbackEl.textContent = errorMessage;
        feedbackEl.style.display = 'block';
      }
    }

    return isValid;
  }

  // Real-time validation
  Object.values(fields).forEach(field => {
    if (!field) return;

    if (field.type === 'checkbox') {
      field.addEventListener('change', () => validateField(field));
    } else {
      field.addEventListener('blur', () => validateField(field));
      field.addEventListener('input', () => {
        if (field.classList.contains('is-invalid')) {
          validateField(field);
        }
      });
    }
  });

  // Submit Handler
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    let isFormValid = true;
    let firstInvalidField = null;

    const requiredFields = [fields.fullname, fields.email, fields.phone, fields.inquiryType, fields.message, fields.consent];

    requiredFields.forEach(field => {
      const valid = validateField(field);
      if (!valid) {
        isFormValid = false;
        if (!firstInvalidField) {
          firstInvalidField = field;
        }
      }
    });

    if (!isFormValid) {
      if (firstInvalidField) firstInvalidField.focus();
      return;
    }

    // AUTH GUARD: If inquiry is purchase, enforce login first!
    const isInquiryPurchase = fields.inquiryType.value === 'purchase';
    if (isInquiryPurchase && window.Luminare && !window.Luminare.isLoggedIn()) {
      window.Luminare.requireAuth((user) => {
        // Pre-fill user info
        prefillUserInfoIfLoggedIn();
        // Continue submission
        proceedSubmission();
      }, 'กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อผลงาน เพื่อยืนยันตัวตนและการออกใบรับรองของแท้ (COA)');
      return;
    }

    proceedSubmission();

    function proceedSubmission() {
      const originalBtnText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `
        <span class="spinner" style="width: 18px; height: 18px; border-width: 2px; display: inline-block; margin: 0 8px 0 0; vertical-align: middle;"></span>
        กำลังบันทึกและตรวจสอบคำสั่งซื้อ...
      `;

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;

        const customerName = fields.fullname.value.trim();
        const artworkTitle = fields.artwork.value.trim() || 'ผลงานศิลปะร่วมสมัย';
        
        // Find artwork price if available
        let price = 85000;
        let artworkId = null;
        if (window.Luminare) {
          const matchedArt = window.Luminare.getArtworks().find(a => 
            a.title.toLowerCase().includes(artworkTitle.toLowerCase()) || 
            artworkTitle.toLowerCase().includes(a.title.toLowerCase())
          );
          if (matchedArt) {
            price = matchedArt.price;
            artworkId = matchedArt.id;
          }
        }

        // Save order to Luminare storage
        let createdOrder = null;
        if (window.Luminare && isInquiryPurchase) {
          createdOrder = window.Luminare.createOrder({
            customerName: customerName,
            email: fields.email.value.trim(),
            phone: fields.phone.value.trim(),
            artworkId: artworkId,
            artworkTitle: artworkTitle,
            price: price,
            address: fields.message.value.trim()
          });
        }

        // Display "สั่งซื้อสำเร็จ (Order Placed Successfully!)" Modal Dialog
        showOrderSuccessModal({
          orderId: createdOrder ? createdOrder.orderId : ('LUM-' + Math.floor(100000 + Math.random() * 900000)),
          customerName: customerName,
          email: fields.email.value.trim(),
          phone: fields.phone.value.trim(),
          artworkTitle: artworkTitle,
          price: price,
          isPurchase: isInquiryPurchase
        });

        // Reset form
        form.reset();
        Object.values(fields).forEach(f => {
          if (f) {
            f.classList.remove('is-valid');
            f.classList.remove('is-invalid');
          }
        });
      }, 900);
    }
  });
}

/**
 * Renders and displays the Order Success Modal Dialog
 */
function showOrderSuccessModal(orderData) {
  let modal = document.getElementById('order-success-modal');
  if (!modal) {
    const modalHTML = `
      <div class="modal-overlay order-success-modal" id="order-success-modal" role="dialog" aria-modal="true" aria-labelledby="order-success-title">
        <div class="modal-container">
          <div class="success-icon-badge">
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
              <polyline points="22 4 12 14.01 9 11.01"></polyline>
            </svg>
          </div>

          <h2 id="order-success-title" style="font-size: 1.65rem; color: var(--text-primary); margin-bottom: 0.35rem;">
            ${orderData.isPurchase ? '🎉 สั่งซื้อผลงานศิลปะสำเร็จเรียบร้อย!' : '✨ ส่งข้อความติดต่อสำเร็จเรียบร้อย!'}
          </h2>
          <p style="font-size: 0.95rem; color: var(--text-secondary);">
            ขอบพระคุณคุณ <strong>${orderData.customerName}</strong> ระบบได้บันทึกคำสั่งซื้อและออกใบเสร็จรับเงินเบื้องต้นแล้ว
          </p>

          <div class="order-receipt-box">
            <div class="receipt-row">
              <span style="color: var(--text-tertiary);">รหัสคำสั่งซื้อ (Order ID):</span>
              <strong style="color: var(--accent-gold); font-family: var(--font-heading);">${orderData.orderId}</strong>
            </div>
            <div class="receipt-row">
              <span style="color: var(--text-tertiary);">ผลงานที่สั่งซื้อ:</span>
              <strong>${orderData.artworkTitle}</strong>
            </div>
            <div class="receipt-row">
              <span style="color: var(--text-tertiary);">อีเมลยืนยัน:</span>
              <span>${orderData.email}</span>
            </div>
            <div class="receipt-row">
              <span style="color: var(--text-tertiary);">เบอร์โทรศัพท์:</span>
              <span>${orderData.phone}</span>
            </div>
            <div class="receipt-row">
              <span style="color: var(--text-tertiary);">สถานะ:</span>
              <span class="badge badge-available">● บันทึกคำสั่งซื้อสำเร็จ</span>
            </div>
            ${orderData.isPurchase ? `
              <div class="receipt-row">
                <span>ยอดรวมทั้งสิ้น:</span>
                <span>฿${orderData.price.toLocaleString('th-TH')}</span>
              </div>
            ` : ''}
          </div>

          <p style="font-size: 0.85rem; color: var(--text-tertiary); margin-bottom: 1.5rem; line-height: 1.5;">
            * เจ้าหน้าที่ภัณฑารักษ์จะโทรประสานงานเรื่องการนัดหมายส่งมอบพร้อมใบ Certificate of Authenticity ภายใน 24 ชม.
          </p>

          <div style="display: flex; gap: 0.75rem; justify-content: center;">
            <button type="button" class="btn btn-outline" id="btn-print-receipt">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
              พิมพ์ใบยืนยัน
            </button>
            <a href="gallery.html" class="btn btn-primary">
              ชมผลงานอื่นต่อ
            </a>
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    modal = document.getElementById('order-success-modal');

    // Attach print button
    modal.querySelector('#btn-print-receipt')?.addEventListener('click', () => {
      window.print();
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('is-active');
        document.body.style.overflow = '';
      }
    });
  }

  modal.classList.add('is-active');
  document.body.style.overflow = 'hidden';
}

function prefillArtworkFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const artworkParam = params.get('artwork');
  const inquiryParam = params.get('inquiry');

  const artworkField = document.getElementById('contact-artwork');
  const typeField = document.getElementById('contact-type');

  if (artworkParam && artworkField) {
    artworkField.value = decodeURIComponent(artworkParam);
    if (typeField && !inquiryParam) {
      typeField.value = 'purchase';
    }
  }

  if (inquiryParam && typeField) {
    if (inquiryParam === 'curator') {
      typeField.value = 'exhibition';
    }
  }
}

function initFaqAccordion() {
  const faqButtons = document.querySelectorAll('.faq-question-btn');

  faqButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const parentItem = btn.closest('.faq-item');
      const isOpen = parentItem.classList.contains('is-open');

      document.querySelectorAll('.faq-item').forEach(item => {
        if (item !== parentItem) {
          item.classList.remove('is-open');
          item.querySelector('.faq-question-btn')?.setAttribute('aria-expanded', 'false');
        }
      });

      parentItem.classList.toggle('is-open', !isOpen);
      btn.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
    });
  });
}
