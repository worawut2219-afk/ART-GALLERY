/**
 * Luminare Art Gallery & Exhibition
 * Gallery Catalog: Search, Filter, Sort, Artwork Modal, and Auth Guard for Purchasing
 */

class GalleryCatalog {
  constructor() {
    // Load artworks from shared Luminare storage (syncs with Admin changes)
    this.artworks = window.Luminare ? window.Luminare.getArtworks() : [];
    this.filteredArtworks = [...this.artworks];
    this.currentCategory = 'all';
    this.currentAvailability = 'all';
    this.currentSort = 'newest';
    this.searchQuery = '';

    this.cacheElements();
    if (this.gridContainer) {
      this.initEventListeners();
      this.handleUrlParameters();
      this.applyFilters();
    }
  }

  cacheElements() {
    this.gridContainer = document.getElementById('gallery-artworks-grid');
    this.searchInput = document.getElementById('gallery-search-input');
    this.clearSearchBtn = document.getElementById('gallery-clear-search');
    this.categoryPills = document.querySelectorAll('.category-filter-pills .filter-pill');
    this.availabilitySelect = document.getElementById('gallery-filter-availability');
    this.sortSelect = document.getElementById('gallery-sort-select');
    this.countLabel = document.getElementById('gallery-results-count');
    this.emptyState = document.getElementById('gallery-empty-state');
    this.modalOverlay = document.getElementById('artwork-detail-modal');
  }

  initEventListeners() {
    // Search Input with real-time response
    if (this.searchInput) {
      this.searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.trim().toLowerCase();
        if (this.clearSearchBtn) {
          this.clearSearchBtn.classList.toggle('is-visible', this.searchQuery.length > 0);
        }
        this.applyFilters();
      });
    }

    // Clear Search Button
    if (this.clearSearchBtn) {
      this.clearSearchBtn.addEventListener('click', () => {
        if (this.searchInput) {
          this.searchInput.value = '';
          this.searchQuery = '';
          this.clearSearchBtn.classList.remove('is-visible');
          this.searchInput.focus();
          this.applyFilters();
        }
      });
    }

    // Category Filter Pills
    this.categoryPills.forEach(pill => {
      pill.addEventListener('click', () => {
        this.categoryPills.forEach(p => p.classList.remove('is-active'));
        pill.classList.add('is-active');
        this.currentCategory = pill.getAttribute('data-category');
        this.applyFilters();
      });
    });

    // Availability Filter
    if (this.availabilitySelect) {
      this.availabilitySelect.addEventListener('change', (e) => {
        this.currentAvailability = e.target.value;
        this.applyFilters();
      });
    }

    // Sort Dropdown
    if (this.sortSelect) {
      this.sortSelect.addEventListener('change', (e) => {
        this.currentSort = e.target.value;
        this.applyFilters();
      });
    }

    // Setup Modal Controls
    this.initModalControls();
  }

  handleUrlParameters() {
    const params = new URLSearchParams(window.location.search);
    const categoryParam = params.get('category');
    if (categoryParam) {
      this.currentCategory = categoryParam;
      this.categoryPills.forEach(pill => {
        if (pill.getAttribute('data-category') === categoryParam) {
          pill.classList.add('is-active');
        } else {
          pill.classList.remove('is-active');
        }
      });
    }
  }

  applyFilters() {
    // Re-fetch latest in case admin updated
    if (window.Luminare) {
      this.artworks = window.Luminare.getArtworks();
    }

    this.filteredArtworks = this.artworks.filter(art => {
      // Category Match
      const matchesCategory = (this.currentCategory === 'all' || art.category === this.currentCategory);

      // Availability Match
      const matchesAvailability = (
        this.currentAvailability === 'all' ||
        (this.currentAvailability === 'available' && art.status === 'available') ||
        (this.currentAvailability === 'sold' && art.status === 'sold')
      );

      // Search Query Match (Title, Artist, Medium, Category)
      const matchesSearch = !this.searchQuery || (
        art.title.toLowerCase().includes(this.searchQuery) ||
        art.artist.toLowerCase().includes(this.searchQuery) ||
        art.categoryName.toLowerCase().includes(this.searchQuery) ||
        art.medium.toLowerCase().includes(this.searchQuery)
      );

      return matchesCategory && matchesAvailability && matchesSearch;
    });

    // Apply Sorting
    this.sortArtworks();

    // Render results to DOM
    this.render();
  }

  sortArtworks() {
    switch (this.currentSort) {
      case 'price-asc':
        this.filteredArtworks.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        this.filteredArtworks.sort((a, b) => b.price - a.price);
        break;
      case 'title-asc':
        this.filteredArtworks.sort((a, b) => a.title.localeCompare(b.title, 'th'));
        break;
      case 'newest':
      default:
        this.filteredArtworks.sort((a, b) => b.year - a.year);
        break;
    }
  }

  render() {
    if (!this.gridContainer) return;

    // Update count label
    if (this.countLabel) {
      this.countLabel.textContent = `พบผลงานศิลปะ ${this.filteredArtworks.length} รายการ`;
    }

    // Toggle Empty State
    if (this.filteredArtworks.length === 0) {
      this.gridContainer.innerHTML = '';
      if (this.emptyState) this.emptyState.style.display = 'block';
      return;
    }

    if (this.emptyState) this.emptyState.style.display = 'none';

    // Render Artwork Cards
    this.gridContainer.innerHTML = this.filteredArtworks.map(art => `
      <article class="art-card" data-id="${art.id}">
        <div class="art-card-media">
          <img src="${art.image}" alt="${art.title} โดย ${art.artist}" class="art-card-img" loading="lazy">
          <div class="art-card-badges">
            <span class="badge badge-category">${art.categoryName}</span>
            <span class="badge ${art.status === 'available' ? 'badge-available' : 'badge-sold'}">
              ${art.status === 'available' ? '● พร้อมจำหน่าย' : '○ จัดแสดงแล้ว'}
            </span>
          </div>
        </div>

        <div class="art-card-content">
          <div class="art-card-meta">
            <span>ปี ค.ศ. ${art.year}</span>
            <span>${art.dimensions}</span>
          </div>

          <h3 class="art-card-title">${art.title}</h3>
          <p class="art-card-artist">${art.artist}</p>
          
          <div class="art-card-specs">
            <span class="art-card-spec-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
              ${art.medium}
            </span>
          </div>

          <div class="art-card-footer">
            <div>
              <div class="art-price-label">${art.status === 'available' ? 'ราคาจำหน่าย' : 'มูลค่าผลงาน'}</div>
              <div class="art-price-value">฿${art.price.toLocaleString('th-TH')}</div>
            </div>

            <div class="art-card-actions">
              <button type="button" class="btn btn-outline btn-sm btn-quick-view" data-id="${art.id}" aria-label="ดูรายละเอียดผลงาน ${art.title}">
                ดูรายละเอียด
              </button>
              ${art.status === 'available' ? `
                <button type="button" class="btn btn-primary btn-sm btn-purchase-art" data-id="${art.id}" data-title="${encodeURIComponent(art.title)}" aria-label="สั่งซื้อผลงาน ${art.title}">
                  สั่งซื้อผลงาน
                </button>
              ` : `
                <a href="contact.html?inquiry=curator&artwork=${encodeURIComponent(art.title)}" class="btn btn-outline btn-sm" aria-label="สอบถามข้อมูลผลงาน ${art.title}">
                  สอบถามข้อมูล
                </a>
              `}
            </div>
          </div>
        </div>
      </article>
    `).join('');

    // Attach click listeners to Quick View buttons
    this.gridContainer.querySelectorAll('.btn-quick-view').forEach(btn => {
      btn.addEventListener('click', () => {
        const artId = btn.getAttribute('data-id');
        this.openDetailModal(artId);
      });
    });

    // Attach click listeners to Purchase buttons with LOGIN REQUIREMENT GUARD
    this.gridContainer.querySelectorAll('.btn-purchase-art').forEach(btn => {
      btn.addEventListener('click', () => {
        const artTitle = decodeURIComponent(btn.getAttribute('data-title'));
        const artId = btn.getAttribute('data-id');
        this.handlePurchaseClick(artId, artTitle);
      });
    });
  }

  /**
   * Enforces login before purchasing artwork
   */
  handlePurchaseClick(artId, artTitle) {
    if (!window.Luminare) {
      window.location.href = `contact.html?artwork=${encodeURIComponent(artTitle)}`;
      return;
    }

    window.Luminare.requireAuth((user) => {
      // User is logged in! Proceed to contact & checkout page
      window.location.href = `contact.html?artwork=${encodeURIComponent(artTitle)}&autologin=true`;
    }, `กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อผลงาน "${artTitle}"`);
  }

  /* ===================================================================
     ARTWORK DETAIL MODAL FUNCTIONALITY
     =================================================================== */
  initModalControls() {
    if (!this.modalOverlay) return;

    const closeBtn = this.modalOverlay.querySelector('.modal-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeDetailModal());
    }

    // Close on clicking backdrop outside modal content
    this.modalOverlay.addEventListener('click', (e) => {
      if (e.target === this.modalOverlay) {
        this.closeDetailModal();
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modalOverlay.classList.contains('is-active')) {
        this.closeDetailModal();
      }
    });
  }

  openDetailModal(artId) {
    const art = this.artworks.find(item => item.id === artId);
    if (!art || !this.modalOverlay) return;

    const modalBody = this.modalOverlay.querySelector('.modal-dynamic-content');
    if (!modalBody) return;

    modalBody.innerHTML = `
      <div class="modal-body-grid">
        <div class="modal-media-col">
          <img src="${art.image}" alt="${art.title} โดย ${art.artist}">
        </div>

        <div class="modal-info-col">
          <div class="modal-badges">
            <span class="badge badge-category">${art.categoryName}</span>
            <span class="badge ${art.status === 'available' ? 'badge-available' : 'badge-sold'}">
              ${art.status === 'available' ? '● พร้อมจำหน่าย' : '○ มีผู้สะสมแล้ว'}
            </span>
          </div>

          <h2 class="modal-art-title">${art.title}</h2>
          <p class="modal-art-artist">สร้างสรรค์โดย ${art.artist}</p>

          <p class="modal-art-desc">${art.description}</p>

          <table class="modal-specs-table">
            <tbody>
              <tr>
                <td>เทคนิค/วัสดุ:</td>
                <td>${art.medium}</td>
              </tr>
              <tr>
                <td>ขนาดผลงาน:</td>
                <td>${art.dimensions}</td>
              </tr>
              <tr>
                <td>ปีที่สร้างสรรค์:</td>
                <td>ค.ศ. ${art.year}</td>
              </tr>
              <tr>
                <td>ประวัติศิลปิน:</td>
                <td>${art.artistBio}</td>
              </tr>
              <tr>
                <td>ใบรับรองของแท้:</td>
                <td>มีใบ Certificate of Authenticity ประทับตราหอศิลป์</td>
              </tr>
            </tbody>
          </table>

          <div class="modal-footer-actions">
            <div>
              <div class="art-price-label">${art.status === 'available' ? 'ราคาจำหน่ายสุทธิ' : 'ราคาประเมินผลงาน'}</div>
              <div class="art-price-value text-gold" style="font-size: 1.5rem;">
                ฿${art.price.toLocaleString('th-TH')}
              </div>
            </div>

            <div style="display: flex; gap: 0.75rem;">
              <button type="button" class="btn btn-outline" id="modal-btn-close">ปิด</button>
              ${art.status === 'available' ? `
                <button type="button" class="btn btn-primary" id="modal-btn-purchase" data-id="${art.id}" data-title="${encodeURIComponent(art.title)}">
                  สั่งซื้อผลงานนี้
                </button>
              ` : `
                <a href="contact.html?artwork=${encodeURIComponent(art.title)}" class="btn btn-outline">
                  ติดต่อสอบถามผลงานใกล้เคียง
                </a>
              `}
            </div>
          </div>
        </div>
      </div>
    `;

    // Rebind inner close button
    const innerCloseBtn = modalBody.querySelector('#modal-btn-close');
    if (innerCloseBtn) {
      innerCloseBtn.addEventListener('click', () => this.closeDetailModal());
    }

    // Modal purchase button with login requirement guard
    const modalPurchaseBtn = modalBody.querySelector('#modal-btn-purchase');
    if (modalPurchaseBtn) {
      modalPurchaseBtn.addEventListener('click', () => {
        this.closeDetailModal();
        this.handlePurchaseClick(art.id, art.title);
      });
    }

    this.modalOverlay.classList.add('is-active');
    document.body.style.overflow = 'hidden';
    this.modalOverlay.querySelector('.modal-close-btn')?.focus();
  }

  closeDetailModal() {
    if (!this.modalOverlay) return;
    this.modalOverlay.classList.remove('is-active');
    document.body.style.overflow = '';
  }
}

// Initialize gallery catalog
document.addEventListener('DOMContentLoaded', () => {
  new GalleryCatalog();
});
