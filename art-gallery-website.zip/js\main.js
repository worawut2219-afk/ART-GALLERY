/**
 * Luminare Art Gallery & Exhibition
 * Main JavaScript: Navigation, Dark/Light Mode, Global UI Utilities
 */

document.addEventListener('DOMContentLoaded', () => {
  initThemeToggle();
  initMobileNavigation();
  initHeaderScroll();
  initCurrentPageNav();
});

/* ===================================================================
   FUNCTION 1: DARK / LIGHT MODE SWITCHER (LocalStorage + System Prefs)
   =================================================================== */
function initThemeToggle() {
  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  if (!themeToggleBtn) return;

  const THEME_STORAGE_KEY = 'luminare_gallery_theme';
  
  // Detect stored preference or fall back to system dark mode preference
  const savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  const initialTheme = savedTheme || (systemPrefersDark ? 'dark' : 'light');
  applyTheme(initialTheme);

  themeToggleBtn.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(newTheme);
    localStorage.setItem(THEME_STORAGE_KEY, newTheme);
  });

  function applyTheme(theme) {
    if (theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
      themeToggleBtn.setAttribute('aria-label', 'สลับเป็นโหมดสว่าง (Light Mode)');
      themeToggleBtn.setAttribute('title', 'สลับเป็นโหมดสว่าง');
    } else {
      document.documentElement.removeAttribute('data-theme');
      themeToggleBtn.setAttribute('aria-label', 'สลับเป็นโหมดมืด (Dark Mode)');
      themeToggleBtn.setAttribute('title', 'สลับเป็นโหมดมืด');
    }
  }

  // Listen to system theme change if no manual preference stored
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (!localStorage.getItem(THEME_STORAGE_KEY)) {
      applyTheme(e.matches ? 'dark' : 'light');
    }
  });
}

/* ===================================================================
   FUNCTION 2: MOBILE HAMBURGER MENU NAVIGATION
   =================================================================== */
function initMobileNavigation() {
  const navToggleBtn = document.getElementById('mobile-nav-toggle');
  const mainNav = document.getElementById('main-nav');
  
  if (!navToggleBtn || !mainNav) return;

  function toggleMenu(isOpen) {
    const shouldOpen = isOpen !== undefined ? isOpen : !mainNav.classList.contains('is-open');
    
    navToggleBtn.classList.toggle('is-active', shouldOpen);
    mainNav.classList.toggle('is-open', shouldOpen);
    navToggleBtn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
    
    // Prevent body scrolling when mobile menu is open
    document.body.style.overflow = shouldOpen ? 'hidden' : '';
  }

  navToggleBtn.addEventListener('click', () => toggleMenu());

  // Close menu when clicking on any nav link
  const navLinks = mainNav.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (mainNav.classList.contains('is-open')) {
        toggleMenu(false);
      }
    });
  });

  // Close menu when pressing Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mainNav.classList.contains('is-open')) {
      toggleMenu(false);
      navToggleBtn.focus();
    }
  });

  // Close menu if window is resized to desktop width
  window.addEventListener('resize', () => {
    if (window.innerWidth > 992 && mainNav.classList.contains('is-open')) {
      toggleMenu(false);
    }
  });
}

/* ===================================================================
   HEADER ELEVATION ON SCROLL
   =================================================================== */
function initHeaderScroll() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.08)';
    } else {
      header.style.boxShadow = 'none';
    }
  }, { passive: true });
}

/* ===================================================================
   ACTIVE LINK HIGHLIGHTING
   =================================================================== */
function initCurrentPageNav() {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const navLinks = document.querySelectorAll('.nav-link');

  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (currentPath === '' && href === 'index.html')) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    } else {
      link.classList.remove('active');
      link.removeAttribute('aria-current');
    }
  });
}
