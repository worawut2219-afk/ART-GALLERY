/**
 * Luminare Art Gallery & Exhibition
 * Weather API Integration (Open-Meteo Public API)
 * Features: async/await, loading state, error handling, retry mechanism
 */

const WEATHER_API_URL = 'https://api.open-meteo.com/v1/forecast?latitude=13.7563&longitude=100.5018&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&timezone=Asia%2FBangkok';

/**
 * Maps WMO Weather Interpretation Codes to Thai description and Icon
 * https://open-meteo.com/en/docs
 */
function interpretWeatherCode(code, isDay = 1) {
  const weatherMap = {
    0: { desc: 'ท้องฟ้าแจ่มใส แดดออกปลอดโปร่ง', icon: isDay ? '☀️' : '🌙' },
    1: { desc: 'ท้องฟ้าแจ่มใสเป็นส่วนใหญ่', icon: isDay ? '🌤️' : '🌤️' },
    2: { desc: 'มีเมฆบางส่วน อากาศสบาย', icon: '⛅' },
    3: { desc: 'มีเมฆปกคลุมเป็นส่วนใหญ่', icon: '☁️' },
    45: { desc: 'มีหมอกบางลงพื้นที่', icon: '🌫️' },
    48: { desc: 'หมอกหนาจัด', icon: '🌫️' },
    51: { desc: 'ฝนตกปรอยๆ เล็กน้อย', icon: '🌦️' },
    53: { desc: 'ฝนตกปรอยๆ ปานกลาง', icon: '🌦️' },
    55: { desc: 'ฝนตกปรอยๆ หนาเม็ด', icon: '🌧️' },
    61: { desc: 'ฝนตกเล็กน้อย', icon: '🌧️' },
    63: { desc: 'ฝนตกปานกลาง', icon: '🌧️' },
    65: { desc: 'ฝนตกหนัก', icon: '⛈️' },
    80: { desc: 'ฝนซู่กระจายบางแห่ง', icon: '🌦️' },
    81: { desc: 'ฝนซู่ปานกลาง', icon: '🌧️' },
    82: { desc: 'ฝนฟ้าคะนองและตกหนัก', icon: '⛈️' },
    95: { desc: 'พายุฝนฟ้าคะนอง', icon: '⚡' }
  };

  return weatherMap[code] || { desc: 'สภาพอากาศทั่วไป', icon: '🌤️' };
}

/**
 * Returns visiting recommendation according to weather conditions
 */
function getVisitingTip(temp, code) {
  if (code >= 51 && code <= 99) {
    return '🌧️ วันนี้มีฝนตกในพื้นที่กรุงเทพฯ เหมาะแก่การหลบฝนเข้ามาเดินชมงานศิลปะในหอศิลป์ติดแอร์เย็นสบาย พร้อมบริการร่มและจุดรับฝากสัมภาระฟรี';
  } else if (temp >= 35) {
    return '☀️ สภาพอากาศภายนอกค่อนข้างร้อนอบอ้าว ขอเชิญเข้ามาพักผ่อนคลายร้อนพร้อมเสพงานศิลป์ในห้องจัดแสดงควบคุมอุณหภูมิ 22-24°C';
  } else if (temp <= 28) {
    return '🌿 อากาศกำลังสบาย เหมาะมากสำหรับการเดินชมนิทรรศการทั้งห้องแสดงศิลปะและลานประติมากรรมกลางแจ้ง';
  } else {
    return '✨ สภาพอากาศเอื้ออำนวย เหมาะแก่การนัดพบปะเพื่อนฝูงหรือมาเดินดื่มด่ำกับผลงานศิลปะร่วมสมัยตลอดทั้งวัน';
  }
}

/**
 * Fetches real-time weather from Open-Meteo API using async/await
 */
async function fetchGalleryWeather() {
  const container = document.getElementById('gallery-weather-widget');
  if (!container) return;

  // 1. Show Loading State
  container.innerHTML = `
    <div class="weather-loading-box" role="status" aria-live="polite">
      <div class="spinner" aria-hidden="true"></div>
      <p><strong>กำลังดึงข้อมูลสภาพอากาศและบรรยากาศหอศิลป์...</strong></p>
      <small style="color: var(--text-tertiary);">ข้อมูลสดจาก Open-Meteo API (พิกัดกรุงเทพมหานคร)</small>
    </div>
  `;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 9000); // 9 seconds timeout

    const response = await fetch(WEATHER_API_URL, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`เซิร์ฟเวอร์ตอบกลับรหัสข้อผิดพลาด: HTTP ${response.status}`);
    }

    const data = await response.json();

    if (!data.current) {
      throw new Error('โครงสร้างข้อมูลสภาพอากาศไม่ถูกต้อง');
    }

    // 2. Render successful state
    renderWeatherWidget(container, data);

  } catch (error) {
    // 3. Error Handling State
    console.error('Weather API fetch error:', error);
    renderWeatherError(container, error.message || 'ไม่สามารถเชื่อมต่อข้อมูลสภาพอากาศได้ในขณะนี้');
  }
}

/**
 * Render weather widget upon successful data fetch
 */
function renderWeatherWidget(container, data) {
  const cur = data.current;
  const temp = Math.round(cur.temperature_2m);
  const feelsLike = Math.round(cur.apparent_temperature);
  const humidity = cur.relative_humidity_2m;
  const wind = cur.wind_speed_10m;
  const precipitation = cur.precipitation;
  const weatherInfo = interpretWeatherCode(cur.weather_code, cur.is_day);
  const visitTip = getVisitingTip(temp, cur.weather_code);

  container.innerHTML = `
    <div class="weather-header">
      <div>
        <h3 class="weather-location-title">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
            <circle cx="12" cy="10" r="3"></circle>
          </svg>
          สภาพอากาศ ณ บริเวณหอศิลป์ (ปทุมวัน, กรุงเทพฯ)
        </h3>
        <p style="font-size: 0.88rem; color: var(--text-secondary); margin-top: 0.25rem;">
          ข้อมูลบรรยากาศแบบเรียลไทม์เพื่อวางแผนการเดินทางเข้าชมงานศิลป์
        </p>
      </div>
      <span class="weather-source-tag">Live Open-Meteo API</span>
    </div>

    <div class="weather-content-grid">
      <div class="weather-main-highlight">
        <div class="weather-icon-wrapper" aria-hidden="true">${weatherInfo.icon}</div>
        <div>
          <div class="weather-temp-number">${temp}°C</div>
          <div class="weather-condition-text">${weatherInfo.desc}</div>
        </div>
      </div>

      <div class="weather-details-grid">
        <div class="weather-detail-item">
          <div class="weather-detail-label">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            รู้สึกเหมือน (Feels like)
          </div>
          <div class="weather-detail-val">${feelsLike}°C</div>
        </div>

        <div class="weather-detail-item">
          <div class="weather-detail-label">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>
            ความชื้นสัมพัทธ์
          </div>
          <div class="weather-detail-val">${humidity}%</div>
        </div>

        <div class="weather-detail-item">
          <div class="weather-detail-label">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2"/></svg>
            ความเร็วลม
          </div>
          <div class="weather-detail-val">${wind} km/h</div>
        </div>
      </div>
    </div>

    <div class="weather-visit-tip">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="16" x2="12" y2="12"></line>
        <line x1="12" y1="8" x2="12.01" y2="8"></line>
      </svg>
      <div>${visitTip}</div>
    </div>
  `;
}

/**
 * Render error state with retry button
 */
function renderWeatherError(container, errorMessage) {
  container.innerHTML = `
    <div class="weather-error-box" role="alert">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
      </svg>
      <h4>เกิดข้อผิดพลาดในการโหลดข้อมูลสภาพอากาศ</h4>
      <p style="margin: 0.5rem 0 1.25rem 0; font-size: 0.92rem; color: var(--text-secondary);">
        ${errorMessage}
      </p>
      <button type="button" class="btn btn-outline btn-sm" id="btn-weather-retry">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <polyline points="23 4 23 10 17 10"></polyline>
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
        </svg>
        ลองใหม่อีกครั้ง (Retry)
      </button>
    </div>
  `;

  const retryBtn = document.getElementById('btn-weather-retry');
  if (retryBtn) {
    retryBtn.addEventListener('click', () => {
      fetchGalleryWeather();
    });
  }
}

// Auto-run if weather container exists on page
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('gallery-weather-widget')) {
    fetchGalleryWeather();
  }
});
